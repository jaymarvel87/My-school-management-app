import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / 'db.sqlite3'
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

# Find & delete invalid SMSAlert rows
c.execute("SELECT * FROM school_smsalert WHERE student_id NOT IN (SELECT id FROM school_student)")
invalid_sms = c.fetchall()
print(f"Found {len(invalid_sms)} invalid SMSAlert rows: {invalid_sms}")

c.execute("DELETE FROM school_smsalert WHERE student_id NOT IN (SELECT id FROM school_student)")
deleted_sms = c.rowcount
print(f"Deleted {deleted_sms} invalid SMSAlert rows")

# Find & delete invalid Leaderboard rows (similar issue)
c.execute("SELECT * FROM school_leaderboard WHERE student_id NOT IN (SELECT id FROM school_student)")
invalid_leader = c.fetchall()
print(f"Found {len(invalid_leader)} invalid Leaderboard rows: {invalid_leader}")

c.execute("DELETE FROM school_leaderboard WHERE student_id NOT IN (SELECT id FROM school_student)")
deleted_leader = c.rowcount
print(f"Deleted {deleted_leader} invalid Leaderboard rows")

conn.commit()
conn.close()
print("DB fixed! Rerun: python manage.py migrate")
