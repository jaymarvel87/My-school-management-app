# Paste this into nano school/views.py around line 300 (search Ctrl+W "def ai_study_tips")
@login_required
def ai_study_tips(request):
    from django.contrib import messages
    if not FeatureToggle.objects.filter(name="AI Study Tips").exists() or not FeatureToggle.objects.get(name="AI Study Tips").is_enabled:
        messages.warning(request, 'AI Tips feature disabled.')
        return redirect('dashboard')
    if request.method == 'POST':
        category = request.POST.get('category', 'math')
        tip_text = f"Practice {category} daily for 20% improvement—focus on weak areas like equations."
        tip = StudyTip.objects.create(
            student=request.user,
            tip_text=tip_text,
            category=category,
            date_added=timezone.now()
        )
        messages.success(request, f'Tip saved: {tip_text}')
        return redirect('ai_study_tips')
    tips = StudyTip.objects.filter(student=request.user).order_by('-date_added')[:10]
    context = {'tips': tips, 'title': 'AI Study Tips'}
    return render(request, 'school/ai_study_tips.html', context)
