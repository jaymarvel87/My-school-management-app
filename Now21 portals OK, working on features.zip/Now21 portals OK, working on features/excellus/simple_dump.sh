#!/bin/bash
echo "=== SIMPLE PROJECT DUMP (run from root with manage.py) ==="
echo "Current dir: $(pwd)"
echo "Files found:"
find . -type f \( -name "*.py" -o -name "*.html" -o -name "*.css" -o -name "*.js" -o -name "requirements.txt" \) 2>/dev/null | head -20  # Limit to 20 for now
echo ""
echo "=== CONTENTS (first few files) ==="
find . -type f \( -name "*.py" -o -name "*.html" \) -print0 | xargs -0 -I {} sh -c 'echo "=== {} ==="; cat "{}" | head -50; echo ""' 2>/dev/null | head -500  # Cat first 50 lines each, total cap 500
echo "=== END (if truncated, run without head limits) ==="
