from django.contrib import admin
from .models import (
    Student, Teacher, ClassModel, Timetable, Quiz, QuizResult, Grade, Homework,
    Attendance, Fee, Exam, ExamResult, Behavior, Meeting, ParentProfile,
    Message, PageBlock, SiteConfig, DashboardWidget, SiteTheme, FeatureToggle, SystemLog
)

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['user', 'student_id', 'grade_level']
    search_fields = ['user__username', 'student_id']

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['user', 'subject']
    search_fields = ['user__username']

admin.site.register(ClassModel)
admin.site.register(Timetable)
admin.site.register(Quiz)
admin.site.register(QuizResult)
admin.site.register(Grade)
admin.site.register(Homework)
admin.site.register(Attendance)
admin.site.register(Fee)
admin.site.register(Exam)
admin.site.register(ExamResult)
admin.site.register(Behavior)
admin.site.register(Meeting)
admin.site.register(ParentProfile)
admin.site.register(Message)
admin.site.register(PageBlock)
admin.site.register(SiteConfig)
admin.site.register(DashboardWidget)
admin.site.register(SiteTheme)
admin.site.register(FeatureToggle)
admin.site.register(SystemLog)
