from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.utils import timezone
from .models import Student, Teacher, ClassModel, Timetable, Meeting, PeerReview

class StudentForm(UserCreationForm):
    student_id = forms.CharField(max_length=50, required=False, help_text="Optional student ID")
    grade_level = forms.CharField(max_length=10, initial='Grade 10', help_text="e.g., Grade 10")

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'student_id', 'grade_level']

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
            student = Student.objects.create(
                user=user,
                student_id=self.cleaned_data['student_id'],
                grade_level=self.cleaned_data['grade_level'],
                created_at=timezone.now()
            )
        return user

class TeacherForm(UserCreationForm):
    subject = forms.CharField(max_length=50, initial='General', help_text="Subject taught")

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'subject']

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
            Teacher.objects.create(
                user=user,
                subject=self.cleaned_data['subject'],
                created_at=timezone.now()
            )
        return user

class ClassForm(forms.ModelForm):
    class Meta:
        model = ClassModel
        fields = ['name', 'grade_level']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'grade_level': forms.TextInput(attrs={'class': 'form-control'}),
        }

class TimetableForm(forms.ModelForm):
    class Meta:
        model = Timetable
        fields = ['day', 'period', 'subject']
        widgets = {
            'day': forms.Select(choices=[('Mon', 'Monday'), ('Tue', 'Tuesday'), ('Wed', 'Wednesday'), ('Thu', 'Thursday'), ('Fri', 'Friday'), ('Sat', 'Saturday'), ('Sun', 'Sunday')], attrs={'class': 'form-control'}),
            'period': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 8}),
            'subject': forms.TextInput(attrs={'class': 'form-control'}),
         }

class MeetingForm(forms.ModelForm):
    class Meta:
        model = Meeting
        fields = ['title', 'date', 'notes']
        widgets = {
            'date': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class PeerReviewForm(forms.ModelForm):
    class Meta:
        model = PeerReview
        fields = ['rating', 'feedback']
        widgets = {
            'rating': forms.Select(attrs={'class': 'form-control'}),
            'feedback': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
