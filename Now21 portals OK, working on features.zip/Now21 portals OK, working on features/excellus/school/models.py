from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import date

# UI EDITOR MODELS
class PageBlock(models.Model):
    page = models.CharField(max_length=100, default='dashboard')
    block_type = models.CharField(max_length=50)
    content = models.TextField(blank=True)
    styles = models.JSONField(default=dict)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']
        unique_together = ['page', 'order']

    def __str__(self):
        return f"{self.page} - {self.block_type}"

class SiteConfig(models.Model):
    key = models.CharField(max_length=100, unique=True)
    value = models.TextField(blank=True)
    file = models.FileField(upload_to='config/', blank=True)

    def __str__(self):
        return self.key

# SUPER ADMIN MODELS
class DashboardWidget(models.Model):
    name = models.CharField(max_length=100)
    component = models.CharField(max_length=100)
    order = models.IntegerField(default=0)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.name

class SiteTheme(models.Model):
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return self.name

class FeatureToggle(models.Model):
    name = models.CharField(max_length=100, unique=True)
    is_enabled = models.BooleanField(default=False)

    def __str__(self):
        return self.name

class SystemLog(models.Model):
    level = models.CharField(max_length=10)
    message = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.level}: {self.message[:50]}"

# CORE MODELS
class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    student_id = models.CharField(max_length=50, unique=True, blank=True, null=True)
    grade_level = models.CharField(max_length=10, default='Grade 10')
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.user.username if self.user else 'Unnamed Student'

class ParentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Parent of {self.student}"

class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    subject = models.CharField(max_length=50, default='General')
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.user.username if self.user else 'Unnamed Teacher'

class ClassModel(models.Model):
    name = models.CharField(max_length=50)
    grade_level = models.CharField(max_length=10)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, null=True, blank=True)
    students = models.ManyToManyField(Student)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.name

class Timetable(models.Model):
    class_obj = models.ForeignKey(ClassModel, on_delete=models.CASCADE)
    day = models.CharField(max_length=10)
    period = models.IntegerField()
    subject = models.CharField(max_length=50)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        unique_together = [('class_obj', 'day', 'period')]

    def __str__(self):
        return f"{self.class_obj} - {self.day} Period {self.period}: {self.subject}"

class Quiz(models.Model):
    title = models.CharField(max_length=200)
    questions = models.JSONField(default=list)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title

class QuizResult(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    quiz_title = models.CharField(max_length=200)
    score = models.IntegerField()
    completed_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.student} - {self.quiz_title}: {self.score}"

class Exam(models.Model):
    title = models.CharField(max_length=200)
    date = models.DateField()
    class_level = models.CharField(max_length=10)

    def __str__(self):
        return self.title

class ExamResult(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE)
    score = models.FloatField()
    subject = models.CharField(max_length=50, blank=True)
    completed_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.student} - {self.exam.title}: {self.score}"

class Grade(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.CharField(max_length=50)
    score = models.FloatField()
    letter_grade = models.CharField(max_length=2, blank=True)
    date_assigned = models.DateField(default=date.today)

    def __str__(self):
        return f"{self.student} - {self.subject}: {self.score}"

class Homework(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField()
    assigned_to = models.ManyToManyField(Student)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title

class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(default=date.today)
    status = models.CharField(max_length=10, choices=[('present', 'Present'), ('absent', 'Absent'), ('late', 'Late')])

    class Meta:
        unique_together = [('student', 'date')]

    def __str__(self):
        return f"{self.student} - {self.status} on {self.date}"

class Fee(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    paid = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.student} - {self.amount} due {self.due_date}"

class Behavior(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    description = models.TextField()
    date = models.DateField(default=date.today)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.student} - {self.description[:30]}"

class Meeting(models.Model):
    title = models.CharField(max_length=200, blank=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, blank=True)
    parent = models.ForeignKey(ParentProfile, on_delete=models.CASCADE, null=True, blank=True)
    date = models.DateTimeField()
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title or "Meeting"

class Message(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"Message to {self.user} at {self.timestamp}"

class StudyTip(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE)
    tip_text = models.TextField()
    category = models.CharField(max_length=50)
    date_added = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Tip for {self.student}: {self.tip_text[:50]}"

class Donation(models.Model):
    donor = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')
    message = models.TextField(blank=True)
    date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.donor} donated {self.amount} {self.currency}"

class Leaderboard(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    score = models.IntegerField(default=0)
    class_assigned = models.IntegerField(default=1)
    date_updated = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-score']

    def __str__(self):
        return f"{self.student} - Score: {self.score}"

class SMSAlert(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    message = models.TextField()
    date_sent = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Alert for {self.student}: {self.message[:50]}"

class ChatMessage(models.Model):
    room = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['timestamp']

    def __str__(self):
        return f"{self.room}: {self.content[:50]}"

class HomeworkFeedback(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    feedback = models.TextField()
    feedback_date = models.DateTimeField(default=timezone.now)
    score = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return f"Feedback for {self.student} on {self.homework}"

class Challenge(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    points = models.IntegerField(default=10)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.title

class PeerReview(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE)
    reviewer = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='reviews_given')
    reviewed_student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='reviews_received')
    rating = models.IntegerField(choices=[(1, 'Poor'), (2, 'Fair'), (3, 'Good'), (4, 'Excellent'), (5, 'Outstanding')], default=3)
    feedback = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = [('homework', 'reviewer', 'reviewed_student')]

    def __str__(self):
        return f"{self.reviewer} reviewed {self.reviewed_student} ({self.rating}/5)"
