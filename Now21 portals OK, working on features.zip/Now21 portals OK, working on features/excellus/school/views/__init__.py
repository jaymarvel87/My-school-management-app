# Import all views to make them available as school.views.*
from .auth import *
from .student import *
from .teacher import *
from .parent import *
from .admin import *
from .assessments import *
from .operations import *
from .common import *

# Import specific view classes and functions
from .auth import LoginView, LogoutView, role_based_dashboard
from .student import student_dashboard, student_challenges, student_streak
from .teacher import teacher_dashboard, teacher_analytics
from .parent import parent_portal, parent_payments, parent_alerts, parent_schedule_meeting
from .admin import (
    admin_dashboard, super_admin_portal, user_management, toggle_user_active, 
    user_import, bulk_student_import, bulk_teacher_import
)
from .assessments import (
    quiz_list, quiz_create, quiz_detail, quiz_take,
    grades_list, assign_grade, bulk_grade,
    homework_list, assign_homework, homework_submit,
    exam_list, schedule_exam
)
from .operations import (
    attendance_list, mark_attendance, bulk_attendance_mark,
    behavior_list, behavior_create, behavior_detail,
    meeting_list, meeting_create, meeting_detail,
    lesson_list, lesson_create, lesson_detail,
    # New functions added
    fee_list, update_fee, fee_invoice_pdf, bulk_fee_import,
    timetable_list, send_notification, notification_list,
    send_sms_alert, sms_alerts, advanced_analytics,
    report_card_pdf, class_report, results_list,
    class_gpa_report, behavior_log, assignment_planner,
    achievement_badges, virtual_classroom, peer_review,
    wellness_tracker, study_group_chat, send_message,
    chat, send_chat_message, save_widget_order, add_widget,
    update_theme, toggle_feature, impersonate_user, backup_db,
    clear_cache, run_command, send_test_email, get_performance,
    activity_feed, ui_editor, save_blocks, save_ui_config,
    upload_file, view_user_detail, ai_study_tips, donation_portal,
    leaderboard, calendar_view, messages_view, profile_view,
    quick_actions_view, class_wide_meeting, class_wide_attendance,
    media_list, upload_media, elibrary_list, upload_book,
    download_book, custom_roles
)
from .common import (
    StudentListView, StudentDetailView, StudentCreateView, StudentUpdateView, StudentDeleteView,
    TeacherListView, TeacherDetailView, TeacherCreateView, TeacherUpdateView, TeacherDeleteView,
    ClassListView, ClassDetailView, ClassCreateView, ClassUpdateView, ClassDeleteView,
    TimetableCreateView, TimetableUpdateView, TimetableView
)
