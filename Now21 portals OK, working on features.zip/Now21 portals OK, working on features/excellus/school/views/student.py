from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone

@login_required
def student_dashboard(request):
    # Sample data for student dashboard
    context = {
        'student': {
            'grade': '5',
            'class_name': 'Class A',
            'streak': 12
        },
        'pending_homework': 3,
        'current_average': 85,
        'attendance_rate': 95,
        'badges_count': 5,
        'upcoming_deadlines': [
            {
                'title': 'Math Assignment',
                'due_date': timezone.now() + timezone.timedelta(days=1),
                'priority_color': 'danger'
            },
            {
                'title': 'Science Project',
                'due_date': timezone.now() + timezone.timedelta(days=3),
                'priority_color': 'warning'
            },
            {
                'title': 'English Essay',
                'due_date': timezone.now() + timezone.timedelta(days=5),
                'priority_color': 'info'
            }
        ],
        'recent_activities': [
            {
                'title': 'Math Quiz Completed',
                'description': 'Scored 92% on Algebra quiz',
                'timestamp': timezone.now() - timezone.timedelta(hours=2),
                'type_color': 'success',
                'icon': 'check-circle'
            },
            {
                'title': 'Science Assignment Submitted',
                'description': 'Submitted ecosystem project',
                'timestamp': timezone.now() - timezone.timedelta(days=1),
                'type_color': 'info',
                'icon': 'book'
            },
            {
                'title': 'New Badge Earned',
                'description': 'Earned "Math Wizard" badge',
                'timestamp': timezone.now() - timezone.timedelta(days=2),
                'type_color': 'warning',
                'icon': 'trophy'
            }
        ]
    }
    return render(request, 'school/student_dashboard.html', context)

@login_required
def student_challenges(request):
    challenges = [
        {
            'title': 'Math Challenge',
            'description': 'Complete 10 algebra problems',
            'points': 100,
            'deadline': '2025-11-25',
            'participants': 24,
            'difficulty': 'Intermediate'
        },
        {
            'title': 'Science Quiz',
            'description': 'Test your knowledge of biology',
            'points': 150,
            'deadline': '2025-11-28',
            'participants': 18,
            'difficulty': 'Advanced'
        },
        {
            'title': 'Reading Marathon',
            'description': 'Read 5 books this month',
            'points': 200,
            'deadline': '2025-12-01',
            'participants': 32,
            'difficulty': 'Beginner'
        }
    ]
    
    context = {
        'challenges': challenges,
        'current_date': timezone.now(),
    }
    return render(request, 'school/student_challenges.html', context)

@login_required
def student_streak(request):
    streak_data = {
        'current_streak': 12,
        'longest_streak': 15,
        'total_days_learned': 45,
        'weekly_progress': [5, 6, 7, 5, 6, 7, 12],  # Last 7 days
        'monthly_goal': 20,
        'days_completed': 12
    }
    
    context = {
        'streak_data': streak_data,
        'current_date': timezone.now(),
    }
    return render(request, 'school/student_streak.html', context)
