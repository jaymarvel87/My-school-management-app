from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone

@login_required
def teacher_dashboard(request):
    # Sample data for teacher dashboard
    context = {
        'current_date': timezone.now(),
        'total_students': 24,
        'total_classes': 3,
        'pending_assignments': 13,
        'classes': [
            {'name': 'Mathematics - Grade 5A', 'student_count': 8, 'average_grade': 85},
            {'name': 'Science - Grade 5B', 'student_count': 8, 'average_grade': 82},
            {'name': 'Mathematics - Grade 6A', 'student_count': 8, 'average_grade': 88},
        ],
        'recent_assignments': [
            {
                'title': 'Algebra Basics',
                'due_date': timezone.now() + timezone.timedelta(days=2),
                'status': 'Pending',
                'status_color': 'warning',
                'submitted': 5,
                'total_students': 24
            },
            {
                'title': 'Science Project',
                'due_date': timezone.now() + timezone.timedelta(days=5),
                'status': 'In Progress',
                'status_color': 'info',
                'submitted': 12,
                'total_students': 24
            },
            {
                'title': 'Geometry Quiz',
                'due_date': timezone.now() - timezone.timedelta(days=1),
                'status': 'Graded',
                'status_color': 'success',
                'submitted': 24,
                'total_students': 24
            }
        ],
        'upcoming_events': [
            {'title': 'Parent-Teacher Meeting', 'date': '2025-11-25', 'type': 'meeting'},
            {'title': 'Science Fair', 'date': '2025-11-28', 'type': 'event'},
            {'title': 'Math Competition', 'date': '2025-12-05', 'type': 'competition'},
        ]
    }
    return render(request, 'school/teacher_dashboard.html', context)

@login_required
def teacher_analytics(request):
    context = {
        'current_date': timezone.now(),
    }
    return render(request, 'school/teacher_analytics.html', context)
