# Simple imports to avoid circular dependencies
from .auth import LoginView, LogoutView, role_based_dashboard
from .student import student_dashboard
from .teacher import teacher_dashboard
from .parent import parent_portal
from .admin import admin_dashboard, super_admin_portal
from .assessments import *
from .operations import *
from .common import *

# Import everything else with wildcards to catch all functions
from .student import *
from .teacher import *
from .parent import *
from .admin import *
