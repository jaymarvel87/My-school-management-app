from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from ..models import DashboardWidget, FeatureToggle, SystemLog

@login_required
def admin_dashboard(request):
    context = {'users': User.objects.all()[:10]}
    return render(request, 'school/admin_dashboard.html', context)

@login_required
def super_admin_portal(request):
    if not request.user.is_superuser:
        messages.error(request, "Access denied")
        return redirect('dashboard')
    context = {
        'widgets': DashboardWidget.objects.all(),
        'features': FeatureToggle.objects.all(),
        'logs': SystemLog.objects.all()[:10],
    }
    return render(request, 'school/super_admin.html', context)
@login_required
def admin_dashboard(request):
    return render(request, 'school/admin_dashboard.html')

@login_required
def super_admin_portal(request):
    return render(request, 'school/super_admin.html')

@login_required
def user_management(request):
    users = User.objects.all()
    return render(request, 'school/user_management.html', {'users': users})

@login_required
def toggle_user_active(request, user_id):
    user = get_object_or_404(User, id=user_id)
    user.is_active = not user.is_active
    user.save()
    messages.success(request, f'User {user.username} status updated')
    return redirect('user_management')

@login_required
def user_import(request):
    if request.method == 'POST':
        messages.success(request, 'Users imported successfully')
        return redirect('user_management')
    return render(request, 'school/user_import.html')

@login_required
def bulk_student_import(request):
    if request.method == 'POST':
        messages.success(request, 'Students imported successfully')
        return redirect('student_list')
    return render(request, 'school/bulk_student_import.html')

@login_required
def bulk_teacher_import(request):
    if request.method == 'POST':
        messages.success(request, 'Teachers imported successfully')
        return redirect('teacher_list')
    return render(request, 'school/bulk_teacher_import.html')
