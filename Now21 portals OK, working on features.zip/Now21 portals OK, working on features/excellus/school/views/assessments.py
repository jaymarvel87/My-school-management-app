from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
import json
from ..models import Quiz, Grade, Homework, Exam, QuizResult, Student

@login_required
def quiz_list(request):
    context = {'quizzes': Quiz.objects.all()}
    return render(request, 'school/quiz_list.html', context)

@login_required
def quiz_create(request):
    if request.method == 'POST':
        Quiz.objects.create(title=request.POST.get('title', 'New Quiz'))
        messages.success(request, 'Quiz created!')
        return redirect('quiz_list')
    return render(request, 'school/quiz_create.html')

@login_required
def quiz_detail(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk)
    return render(request, 'school/quiz_detail.html', {'quiz': quiz})

@csrf_exempt
@login_required
def quiz_take(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk)
    if request.method == 'POST':
        answers = json.loads(request.POST.get('answers', '{}'))
        score = sum(1 for q in quiz.questions if str(q['id']) in answers and answers[str(q['id'])] == q['correct'])
        QuizResult.objects.create(
            student=Student.objects.get(user=request.user),
            quiz_title=quiz.title,
            score=score
        )
        messages.success(request, f'Quiz completed! Score: {score}/{len(quiz.questions)}')
        return redirect('quiz_list')
    return render(request, 'school/quiz_take.html', {'quiz': quiz})

@login_required
def grades_list(request):
    context = {'grades': Grade.objects.all()}
    return render(request, 'school/grades_list.html', context)

@login_required
def assign_grade(request, student_id):
    student = get_object_or_404(Student, pk=student_id)
    if request.method == 'POST':
        Grade.objects.create(
            student=student,
            subject=request.POST.get('subject'),
            score=float(request.POST.get('score', 0)),
            date_assigned=timezone.now().date()
        )
        messages.success(request, 'Grade assigned.')
        return redirect('grades_list')
    return render(request, 'school/assign_grade.html', {'student': student})

@login_required
def bulk_grade(request):
    if request.method == 'POST':
        messages.success(request, 'Bulk grades assigned.')
        return redirect('grades_list')
    return render(request, 'school/bulk_grade.html')

@login_required
def homework_list(request):
    context = {'homework': Homework.objects.all()}
    return render(request, 'school/homework_list.html', context)

@login_required
def assign_homework(request):
    if request.method == 'POST':
        Homework.objects.create(
            title=request.POST.get('title'),
            description=request.POST.get('description'),
            due_date=request.POST.get('due_date')
        )
        messages.success(request, 'Homework assigned.')
        return redirect('homework_list')
    return render(request, 'school/assign_homework.html')

@login_required
def homework_submit(request, hw_id):
    hw = get_object_or_404(Homework, pk=hw_id)
    if request.method == 'POST':
        messages.success(request, 'Homework submitted!')
        return redirect('homework_list')
    return render(request, 'school/homework_submit.html', {'homework': hw})

@login_required
def exam_list(request):
    context = {'exams': Exam.objects.all()}
    return render(request, 'school/exam_list.html', context)

@login_required
def schedule_exam(request):
    if request.method == 'POST':
        Exam.objects.create(
            title=request.POST.get('title'),
            date=request.POST.get('date'),
            class_level=request.POST.get('class_level')
        )
        messages.success(request, 'Exam scheduled!')
        return redirect('exam_list')
    return render(request, 'school/schedule_exam.html')
