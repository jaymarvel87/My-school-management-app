from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.models import User
from ..models import Student, Teacher, ClassModel, Timetable
from ..forms import StudentForm, TeacherForm, ClassForm, TimetableForm

class StudentListView(LoginRequiredMixin, ListView):
    model = Student
    template_name = 'school/student_list.html'
    context_object_name = 'students'

class StudentDetailView(LoginRequiredMixin, DetailView):
    model = Student
    template_name = 'school/student_detail.html'

class StudentCreateView(LoginRequiredMixin, CreateView):
    model = User
    form_class = StudentForm
    template_name = 'school/student_form.html'
    success_url = '/students/'

class StudentUpdateView(LoginRequiredMixin, UpdateView):
    model = Student
    form_class = StudentForm
    template_name = 'school/student_form.html'
    success_url = '/students/'

class StudentDeleteView(LoginRequiredMixin, DeleteView):
    model = Student
    template_name = 'school/student_confirm_delete.html'
    success_url = '/students/'

class TeacherListView(LoginRequiredMixin, ListView):
    model = Teacher
    template_name = 'school/teacher_list.html'
    context_object_name = 'teachers'

class TeacherDetailView(LoginRequiredMixin, DetailView):
    model = Teacher
    template_name = 'school/teacher_detail.html'

class TeacherCreateView(LoginRequiredMixin, CreateView):
    model = User
    form_class = TeacherForm
    template_name = 'school/teacher_form.html'
    success_url = '/teachers/'

class TeacherUpdateView(LoginRequiredMixin, UpdateView):
    model = Teacher
    form_class = TeacherForm
    template_name = 'school/teacher_form.html'
    success_url = '/teachers/'

class TeacherDeleteView(LoginRequiredMixin, DeleteView):
    model = Teacher
    template_name = 'school/teacher_confirm_delete.html'
    success_url = '/teachers/'

class ClassListView(LoginRequiredMixin, ListView):
    model = ClassModel
    template_name = 'school/class_list.html'
    context_object_name = 'classes'

class ClassDetailView(LoginRequiredMixin, DetailView):
    model = ClassModel
    template_name = 'school/class_detail.html'

class ClassCreateView(LoginRequiredMixin, CreateView):
    model = ClassModel
    form_class = ClassForm
    template_name = 'school/class_form.html'
    success_url = '/classes/'

class ClassUpdateView(LoginRequiredMixin, UpdateView):
    model = ClassModel
    form_class = ClassForm
    template_name = 'school/class_form.html'
    success_url = '/classes/'

class ClassDeleteView(LoginRequiredMixin, DeleteView):
    model = ClassModel
    template_name = 'school/class_confirm_delete.html'
    success_url = '/classes/'

class TimetableCreateView(LoginRequiredMixin, CreateView):
    model = Timetable
    form_class = TimetableForm
    template_name = 'school/timetable_form.html'
    success_url = '/timetable/'

class TimetableUpdateView(LoginRequiredMixin, UpdateView):
    model = Timetable
    form_class = TimetableForm
    template_name = 'school/timetable_form.html'
    success_url = '/timetable/'

class TimetableView(LoginRequiredMixin, ListView):
    model = Timetable
    template_name = 'school/timetable_list.html'
    context_object_name = 'timetables'
