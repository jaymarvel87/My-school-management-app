from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.views import View
from django.contrib.auth.decorators import login_required

@login_required
def role_based_dashboard(request):
    """Redirect users to appropriate dashboard based on their role"""
    if request.user.is_superuser:
        return redirect('super_admin')
    elif hasattr(request.user, 'teacher'):
        return redirect('teacher_dashboard')
    elif hasattr(request.user, 'student'):
        return redirect('student_dashboard')
    elif hasattr(request.user, 'parentprofile'):
        return redirect('parent_portal')
    else:
        return redirect('admin_dashboard')

class LoginView(View):
    def get(self, request):
        # If user is already authenticated, redirect to dashboard
        if request.user.is_authenticated:
            return redirect('dashboard')
        return render(request, 'school/login.html')
    
    def post(self, request):
        # Get username and password from POST data with safe handling
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        
        # Validate that both fields are provided
        if not username or not password:
            messages.error(request, 'Please provide both username and password')
            return render(request, 'school/login.html')
        
        # Authenticate user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password')
            return render(request, 'school/login.html')

class LogoutView(View):
    def get(self, request):
        logout(request)
        messages.success(request, 'You have been logged out successfully')
        return redirect('login')
