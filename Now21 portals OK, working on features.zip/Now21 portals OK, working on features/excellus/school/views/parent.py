from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import JsonResponse
import json
from django.views.decorators.csrf import csrf_exempt

@login_required
def parent_portal(request):
    # Get current date
    current_date = timezone.now()
    
    # Sample data - in real implementation, this would come from database
    sample_children = [
        {
            'id': 1,
            'first_name': 'Emma',
            'last_name': 'Smith',
            'grade': '5',
            'class_name': 'Class A',
            'teacher_name': 'Mrs. Johnson',
            'average_grade': 85,
            'attendance': 95,
            'pending_assignments': 3,
            'behavior_score': 'A',
            'last_activity': 'Math assignment submitted'
        },
        {
            'id': 2,
            'first_name': 'Noah',
            'last_name': 'Smith', 
            'grade': '3',
            'class_name': 'Class B',
            'teacher_name': 'Mr. Davis',
            'average_grade': 92,
            'attendance': 98,
            'pending_assignments': 1,
            'behavior_score': 'A+',
            'last_activity': 'Science quiz completed'
        }
    ]
    
    sample_activities = [
        {
            'title': 'Math Assignment Submitted',
            'description': 'Emma submitted her algebra homework',
            'timestamp': timezone.now() - timezone.timedelta(hours=2),
            'child_name': 'Emma Smith',
            'type_color': 'success',
            'icon': 'check-circle'
        },
        {
            'title': 'Science Quiz Graded',
            'description': 'Noah scored 95% on science quiz about ecosystems',
            'timestamp': timezone.now() - timezone.timedelta(days=1),
            'child_name': 'Noah Smith',
            'type_color': 'info',
            'icon': 'chart-line'
        },
        {
            'title': 'Parent-Teacher Meeting Scheduled',
            'description': 'Meeting confirmed with Mrs. Johnson for next week',
            'timestamp': timezone.now() - timezone.timedelta(days=2),
            'child_name': 'Emma Smith',
            'type_color': 'warning',
            'icon': 'calendar'
        },
        {
            'title': 'Attendance Alert',
            'description': 'Noah was absent yesterday',
            'timestamp': timezone.now() - timezone.timedelta(days=3),
            'child_name': 'Noah Smith',
            'type_color': 'danger',
            'icon': 'exclamation-triangle'
        }
    ]
    
    sample_notices = [
        {
            'id': 1,
            'title': 'School Holiday Reminder',
            'message': 'School will be closed next Friday for teacher training day. No classes will be held.',
            'priority': 'info',
            'date': '2025-11-28'
        },
        {
            'id': 2, 
            'title': 'Science Fair Projects',
            'message': 'Annual science fair projects are due next month. Please ensure your child is working on their project.',
            'priority': 'warning',
            'date': '2025-11-25'
        },
        {
            'id': 3,
            'title': 'Parent-Teacher Conferences',
            'message': 'Fall parent-teacher conferences are scheduled for next week. Please book your slot.',
            'priority': 'info',
            'date': '2025-11-22'
        }
    ]
    
    # Calculate overall statistics
    overall_average = round(sum(child['average_grade'] for child in sample_children) / len(sample_children))
    overall_attendance = round(sum(child['attendance'] for child in sample_children) / len(sample_children))
    total_pending = sum(child['pending_assignments'] for child in sample_children)
    
    context = {
        'current_date': current_date,
        'children': sample_children,
        'overall_average': overall_average,
        'overall_attendance': overall_attendance,
        'total_pending': total_pending,
        'notifications': len([act for act in sample_activities if act['type_color'] == 'danger']),
        'recent_activities': sample_activities,
        'important_notices': sample_notices,
    }
    
    return render(request, 'school/parent_portal.html', context)

@login_required
def parent_payments(request):
    # Sample payment data
    payments = [
        {
            'id': 1,
            'description': 'Tuition Fee - Semester 1',
            'amount': 500.00,
            'due_date': '2025-12-15',
            'status': 'Pending',
            'status_color': 'warning',
            'child': 'Emma Smith'
        },
        {
            'id': 2,
            'description': 'Activity Fee',
            'amount': 50.00,
            'due_date': '2025-11-30',
            'status': 'Paid',
            'status_color': 'success',
            'child': 'Both Children'
        },
        {
            'id': 3,
            'description': 'Library Fee',
            'amount': 25.00,
            'due_date': '2025-11-25',
            'status': 'Overdue',
            'status_color': 'danger',
            'child': 'Noah Smith'
        },
        {
            'id': 4,
            'description': 'Sports Equipment',
            'amount': 75.00,
            'due_date': '2025-12-10',
            'status': 'Pending',
            'status_color': 'warning',
            'child': 'Emma Smith'
        }
    ]
    
    total_due = sum(p['amount'] for p in payments if p['status'] in ['Pending', 'Overdue'])
    total_paid = sum(p['amount'] for p in payments if p['status'] == 'Paid')
    
    context = {
        'current_date': timezone.now(),
        'payments': payments,
        'total_due': total_due,
        'total_paid': total_paid,
        'overdue_count': len([p for p in payments if p['status'] == 'Overdue'])
    }
    return render(request, 'school/parent_payments.html', context)

@login_required
def parent_alerts(request):
    # Sample alerts data
    alerts = [
        {
            'id': 1,
            'title': 'Low Attendance Alert',
            'message': 'Emma has missed 3 days this month. Please ensure regular attendance.',
            'priority': 'warning',
            'date': '2025-11-20',
            'child': 'Emma Smith',
            'read': False
        },
        {
            'id': 2,
            'title': 'Assignment Due Tomorrow',
            'message': 'Science project due tomorrow. Please check if your child has completed it.',
            'priority': 'info',
            'date': '2025-11-21',
            'child': 'Noah Smith',
            'read': True
        },
        {
            'id': 3,
            'title': 'Excellent Performance',
            'message': 'Emma scored 100% on the latest math test! Great work!',
            'priority': 'success',
            'date': '2025-11-18',
            'child': 'Emma Smith',
            'read': True
        },
        {
            'id': 4,
            'title': 'Behavior Notice',
            'message': 'Noah received a positive behavior note from his teacher today.',
            'priority': 'success',
            'date': '2025-11-17',
            'child': 'Noah Smith',
            'read': True
        }
    ]
    
    unread_count = len([alert for alert in alerts if not alert['read']])
    
    context = {
        'current_date': timezone.now(),
        'alerts': alerts,
        'unread_count': unread_count,
    }
    return render(request, 'school/parent_alerts.html', context)

@login_required
def parent_schedule_meeting(request):
    # Sample teachers data
    teachers = [
        {
            'id': 1,
            'name': 'Mrs. Johnson',
            'subject': 'Mathematics',
            'email': 'johnson@school.edu',
            'phone': '(555) 123-4567',
            'available_slots': [
                {'day': 'Monday', 'time': '9:00 AM', 'available': True},
                {'day': 'Wednesday', 'time': '2:00 PM', 'available': True},
                {'day': 'Friday', 'time': '10:00 AM', 'available': False}
            ]
        },
        {
            'id': 2,
            'name': 'Mr. Davis',
            'subject': 'Science',
            'email': 'davis@school.edu',
            'phone': '(555) 123-4568',
            'available_slots': [
                {'day': 'Tuesday', 'time': '11:00 AM', 'available': True},
                {'day': 'Thursday', 'time': '3:00 PM', 'available': True}
            ]
        },
        {
            'id': 3,
            'name': 'Ms. Garcia',
            'subject': 'English',
            'email': 'garcia@school.edu',
            'phone': '(555) 123-4569',
            'available_slots': [
                {'day': 'Monday', 'time': '1:00 PM', 'available': True},
                {'day': 'Wednesday', 'time': '9:00 AM', 'available': False},
                {'day': 'Friday', 'time': '2:00 PM', 'available': True}
            ]
        }
    ]
    
    # Sample upcoming meetings
    upcoming_meetings = [
        {
            'teacher': 'Mrs. Johnson',
            'purpose': 'Math Progress Discussion',
            'date': '2025-11-25',
            'time': '2:00 PM',
            'status': 'Confirmed',
            'child': 'Emma Smith'
        },
        {
            'teacher': 'Mr. Davis',
            'purpose': 'Science Project Review',
            'date': '2025-11-28',
            'time': '11:00 AM',
            'status': 'Pending',
            'child': 'Noah Smith'
        }
    ]
    
    context = {
        'current_date': timezone.now(),
        'teachers': teachers,
        'upcoming_meetings': upcoming_meetings,
    }
    return render(request, 'school/parent_schedule_meeting.html', context)

@csrf_exempt
@login_required
def mark_alert_read(request, alert_id):
    """Mark an alert as read (AJAX endpoint)"""
    if request.method == 'POST':
        # In real implementation, update database
        return JsonResponse({'status': 'success', 'message': 'Alert marked as read'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@csrf_exempt
@login_required
def schedule_meeting(request):
    """Schedule a meeting (AJAX endpoint)"""
    if request.method == 'POST':
        data = json.loads(request.body)
        # In real implementation, save to database
        return JsonResponse({
            'status': 'success', 
            'message': 'Meeting scheduled successfully',
            'meeting_id': 12345
        })
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@csrf_exempt
@login_required
def make_payment(request, payment_id):
    """Process payment (AJAX endpoint)"""
    if request.method == 'POST':
        # In real implementation, process payment
        return JsonResponse({
            'status': 'success', 
            'message': 'Payment processed successfully',
            'transaction_id': 'TX' + str(payment_id).zfill(8)
        })
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})
