from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from .models import Student, Meeting
from django.utils import timezone

User = get_user_model()

class SchoolTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user('test', 'test@example.com', 'pass123')
        self.client.login(username='test', password='pass123')
        self.student = Student.objects.create(user=self.user, grade_level='Grade 10')

    def test_parent_portal_access(self):
        response = self.client.get(reverse('parent_portal'))
        self.assertEqual(response.status_code, 302)  # Redirect if no profile

    def test_meeting_creation(self):
        Meeting.objects.create(student=self.student, date=timezone.now())
        self.assertEqual(Meeting.objects.count(), 1)
